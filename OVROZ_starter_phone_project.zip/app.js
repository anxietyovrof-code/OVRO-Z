const items = [
  {id:1,title:"Midnight Mystery",type:"Movies",tag:"Thriller",emoji:"🌌",style:""},
  {id:2,title:"The Last Signal",type:"Series",tag:"Sci-Fi",emoji:"📡",style:"series"},
  {id:3,title:"Match Centre",type:"Sports",tag:"Live scores concept",emoji:"🏏",style:"sports"},
  {id:4,title:"Bangla Natok Picks",type:"Bangla",tag:"Drama discovery",emoji:"🎭",style:"bangla"},
  {id:5,title:"Creator Spotlight",type:"YouTube",tag:"Video discovery",emoji:"▶️",style:"youtube"},
  {id:6,title:"Weekend Watchlist",type:"AI Picks",tag:"Mood-based picks",emoji:"✦",style:"series"}
];
let activeFilter="All";
let query="";
let saved=JSON.parse(localStorage.getItem("ovrozSaved")||"[]");
const grid=document.getElementById("contentGrid");
function render(){
  const shown=items.filter(x=>(activeFilter==="All"||x.type===activeFilter|| (activeFilter==="Movies"&&x.type==="Movies")) && (x.title+" "+x.type+" "+x.tag).toLowerCase().includes(query.toLowerCase()));
  grid.innerHTML="";
  shown.forEach(x=>{
    const card=document.createElement("article");card.className="content-card";
    card.innerHTML=`<div class="poster ${x.style}">${x.emoji}</div><div class="card-info"><b>${x.title}</b><small>${x.type} · ${x.tag}</small><div class="card-actions"><small>OVRO'Z pick</small><button class="save-btn" data-id="${x.id}">${saved.includes(x.id)?"♥ Saved":"♡ Save"}</button></div></div>`;
    grid.appendChild(card);
  });
  document.getElementById("emptyState").classList.toggle("hidden",shown.length>0);
  document.getElementById("listTitle").textContent=activeFilter==="All"?"Featured picks":activeFilter;
}
document.querySelectorAll("[data-filter]").forEach(btn=>btn.addEventListener("click",()=>{
  activeFilter=btn.dataset.filter;
  document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.filter===activeFilter));
  render();document.getElementById("discover").scrollIntoView({behavior:"smooth"});
}));
grid.addEventListener("click",e=>{
  const b=e.target.closest(".save-btn");if(!b)return;
  const id=Number(b.dataset.id);saved=saved.includes(id)?saved.filter(v=>v!==id):[...saved,id];
  localStorage.setItem("ovrozSaved",JSON.stringify(saved));render();
});
document.getElementById("searchToggle").onclick=()=>document.getElementById("searchPanel").classList.toggle("hidden");
document.getElementById("searchInput").addEventListener("input",e=>{query=e.target.value;render()});
document.getElementById("clearSearch").onclick=()=>{document.getElementById("searchInput").value="";query="";render()};
document.getElementById("exploreBtn").onclick=()=>document.getElementById("discover").scrollIntoView({behavior:"smooth"});
document.getElementById("showAll").onclick=()=>{activeFilter="All";query="";document.getElementById("searchInput").value="";render()};
document.querySelectorAll(".nav-item").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("selected"));btn.classList.add("selected");
  if(btn.dataset.page==="My List"){activeFilter="All";query="";render();[...grid.children].forEach(card=>{const title=card.querySelector("b").textContent;const item=items.find(x=>x.title===title);card.classList.toggle("hidden",!saved.includes(item.id))});document.getElementById("listTitle").textContent="My List";}
  else if(btn.dataset.page==="Discover"){document.getElementById("searchPanel").classList.remove("hidden");document.getElementById("discover").scrollIntoView({behavior:"smooth"});}
  else if(btn.dataset.page==="Home"){activeFilter="All";render();window.scrollTo({top:0,behavior:"smooth"});}
  else {document.getElementById("listTitle").textContent="Profile";document.getElementById("discover").scrollIntoView({behavior:"smooth"});}
}));
render();
