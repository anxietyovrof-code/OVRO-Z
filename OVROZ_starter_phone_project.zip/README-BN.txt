OVRO'Z STARTER - ফোন দিয়ে শুরু করার ফাইল

সব ফাইল একই ফোল্ডারে রাখা হয়েছে, যাতে ফোন থেকে GitHub-এ আপলোড সহজ হয়।\n\nএই প্রজেক্টে আছে:
- Responsive entertainment home screen
- Category navigation
- Search
- My List (ব্রাউজারের local storage-এ সংরক্ষণ)
- PWA manifest ও service worker-এর প্রাথমিক সেটআপ

গুরুত্বপূর্ণ:
এটি প্রথম UI prototype। এখানে কোনো সিনেমা, সিরিজ, টিভি চ্যানেল বা লাইভ স্পোর্টস ভিডিও যুক্ত নেই।
শুধু নিজের বা অনুমোদিত ভিডিও/API যুক্ত করবেন। কপিরাইটযুক্ত ভিডিও অনুমতি ছাড়া হোস্ট/রিস্ট্রিম করবেন না।

ফোনে পরের ধাপ:
1. GitHub-এ সাইন ইন করুন।
2. New repository তৈরি করুন, নাম দিন ovroz.
3. এই ZIP Extract করে ফাইলগুলো repository-র মূল ফোল্ডারে Upload files দিয়ে আপলোড করুন।
4. Commit changes করুন।
5. Repository Settings > Pages > Deploy from a branch নির্বাচন করুন।
6. Branch: main, Folder: / (root) নির্বাচন করে Save করুন।
7. প্রকাশিত GitHub Pages URL Chrome-এ খুলুন।
8. Chrome-এর ⋮ মেনু > Add to Home screen / Install app ব্যবহার করুন।

মনে রাখবেন:
GitHub Pages-এ HTTPS চালু থাকলে PWA-এর service worker কাজ করতে পারবে।
প্রথমে ওয়েব ভার্সন চালু করি। পরে আলাদা করে Android APK/native app প্রকাশের পথ ঠিক করব।
